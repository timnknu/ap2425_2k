import shutil

shutil.make_archive('../my-arch', 'zip', '.')